return function(file, line) return { file = file, line = line, enabled = true } end
