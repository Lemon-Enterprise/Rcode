local Trace = {}
function Trace.new() return { frames = {} } end
function Trace.push(trace, name) trace.frames[#trace.frames + 1] = name end
return Trace
