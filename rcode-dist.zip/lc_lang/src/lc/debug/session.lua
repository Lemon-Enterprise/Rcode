local Session = {}
function Session.new() return { breakpoints = require("lc.debug.breakpoints").new(), paused = false } end
return Session
