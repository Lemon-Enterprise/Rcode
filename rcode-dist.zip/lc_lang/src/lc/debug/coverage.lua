local Coverage = {}
function Coverage.new() return { lines = {} } end
function Coverage.hit(coverage, line) coverage.lines[line] = (coverage.lines[line] or 0) + 1 end
return Coverage
