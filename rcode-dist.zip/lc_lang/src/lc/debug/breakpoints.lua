local Breakpoints = {}
function Breakpoints.new() return { values = {} } end
function Breakpoints.add(store, breakpoint) store.values[#store.values + 1] = breakpoint end
return Breakpoints
