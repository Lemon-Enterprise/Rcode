local Profiler = {}
function Profiler.new() return { events = {} } end
function Profiler.mark(profiler, name) profiler.events[#profiler.events + 1] = { name = name, clock = os.clock() } end
return Profiler
