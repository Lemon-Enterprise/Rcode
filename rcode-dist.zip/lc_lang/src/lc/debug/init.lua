return { session = require("lc.debug.session"), profiler = require("lc.debug.profiler"), coverage = require("lc.debug.coverage") }
