local Repl = {}
function Repl.evaluate(expression, environment) return environment and environment:get(expression) or nil end
return Repl
