return require("lc.studio.widgets.factory").make("dialog")
